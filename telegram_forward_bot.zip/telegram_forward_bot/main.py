from telethon import TelegramClient, events
import os

api_id = int(os.getenv("API_ID"))
api_hash = os.getenv("API_HASH")
session_str = os.getenv("SESSION_STRING")
source_channel = int(os.getenv("SOURCE_CHANNEL"))
target_channel = int(os.getenv("TARGET_CHANNEL"))

client = TelegramClient(StringSession(session_str), api_id, api_hash)

@client.on(events.NewMessage(chats=source_channel))
async def handler(event):
    if event.message.media:
        await client.send_file(target_channel, file=event.message.media, caption=event.message.text)
    else:
        await client.send_message(target_channel, message=event.message.text)

client.start()
client.run_until_disconnected()
